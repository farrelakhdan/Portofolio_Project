

<?php $__env->startSection('top'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Small boxes (Stat box) -->
<?php $status = Session::get('ssKode') ?>
<div class="row">
    <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "customer" || $status[0]->role == "reseller" || $status[0]->role == "owner"): ?>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-aqua">
            <div class="inner">
                <h3><?php echo e(\App\User::count()); ?></h3>

                <p>Pengguna</p>
            </div>
            <div class="icon">
                <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">Info Lebih Lanjut<i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
    <!-- ./col -->
    <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "customer" || $status[0]->role == "reseller" || $status[0]->role == "owner"): ?>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-green">
            <div class="inner">
                <h3><?php echo e(\App\Category::count()); ?><sup style="font-size: 20px"></sup></h3>

                <p>Kategori</p>
            </div>
            <div class="icon">
                <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo e(route('categories.index')); ?>" class="small-box-footer">Info Lebih Lanjut <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
    <!-- ./col -->
    <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "customer" || $status[0]->role == "reseller" || $status[0]->role == "owner"): ?>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-yellow">
            <div class="inner">
                <h3><?php echo e(\App\Product::count()); ?></h3>
                <p>Produk</p>
            </div>
            <div class="icon">
                <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(route('products.index')); ?>" class="small-box-footer">Info Lebih Lanjut <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
    <!-- ./col -->
    <!-- ./col -->
</div>



<div class="row">
    <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "customer" || $status[0]->role == "owner"): ?>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-navy">
            <div class="inner">
                <h3><?php echo e(\App\Sale::count()); ?></h3>

                <p>Reseller</p>
            </div>
            <div class="icon">
                <i class="ion ion-bag"></i>
            </div>
            <a href="<?php echo e(route('sales.index')); ?>" class="small-box-footer">Info Lebih Lanjut <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
    <!-- ./col -->
    <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "owner"): ?>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-teal">
            <div class="inner">
                <h3><?php echo e(\App\Supplier::count()); ?><sup style="font-size: 20px"></sup></h3>

                <p>Supplier</p>
            </div>
            <div class="icon">
                <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo e(route('suppliers.index')); ?>" class="small-box-footer">Info Lebih Lanjut <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
    <!-- ./col -->
    <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "owner"): ?>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-maroon">
            <div class="inner">
                <h3><?php echo e(\App\Product_Masuk::count()); ?></h3>

                <p>Produk Masuk</p>
            </div>
            <div class="icon">
                <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(route('productsIn.index')); ?>" class="small-box-footer">Info Lebih Lanjut <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
    <!-- ./col -->
    <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "owner"): ?>
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-gray">
            <div class="inner">
                <h3><?php echo e(\App\Product_Keluar::count()); ?></h3>

                <p>Produk Keluar</p>
            </div>
            <div class="icon">
                <i class="ion ion-pie-graph"></i>
            </div>
            <a href="<?php echo e(route('productsOut.index')); ?>" class="small-box-footer">Info Lebih Lanjut <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
    <!-- ./col -->
</div>
<?php $login = Session::get('status') ?>
<?php if($login == "login"): ?>
<div class="row">
    <div class="box">
        <div class="box-body">
        <div class="callout callout-success">
            <h4>Berhasil</h4>

            <p> Kamu telah masuk!</p>
        </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top'); ?>
<?php $__env->stopSection(); ?>













    
        
            
                

                
                    
                        
                            
                        
                    

                    
                
            
        
    



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/home.blade.php ENDPATH**/ ?>