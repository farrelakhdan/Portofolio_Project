

<?php $__env->startSection('top'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Small boxes (Stat box) -->

<div class="row">
    <div class="box">
        <div class="box-body">
        <div class="callout callout-success">
            <h4>CONTACT PERSON</h4>
            <p> <img src="wa.png" class="user-image" alt="User Image"> +62 812-3507-6283</p>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/info/index.blade.php ENDPATH**/ ?>