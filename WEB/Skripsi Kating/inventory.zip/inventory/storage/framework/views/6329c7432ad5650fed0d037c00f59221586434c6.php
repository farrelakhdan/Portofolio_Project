<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/homeStyle.css">
  <link rel="stylesheet" href="css/navbarStyle.css">
  <title>N'UP PRODUCT</title>
</head>
<body>
  <header>
    <div class="logo">
      <h4>HELLO</h4>
    </div>
    <ul class="nav-links">
      <li>
        <a href="home">CEK PRODUCT</a>
      </li>
      <li>
        <a href="login">LOGIN</a>
      </li>
    </ul>
    <div class="burger">
      <div class="line1"></div>
      <div class="line2"></div>
      <div class="line3"></div>
    </div>
</header>
  <section class="home">
      <img src="<?php echo e(asset("bg.jpeg")); ?>" class="image-slide active" alt="" srcset="">
    <div class="content">
        <h1>Sistem Informasi Persediaan Barang<br><span>N'UP Product</span></h1>
      
    </div>
  </section>
  <script src="js/appnav.js"></script>
  <script src="js/home.js"></script>
</body>
</html><?php /**PATH /home/arrianso/public_html/inventory/resources/views/homeElsa.blade.php ENDPATH**/ ?>