<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(asset('user.png')); ?> " class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <?php $nama = Session::get('nama') ?>
                <?php if($nama[0]->name == "customer"): ?>
                
                <p>Guest</p>
                <?php else: ?>
                
                <p><?php echo $nama[0]->name?></p>
                <?php endif; ?>
                
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form (Optional) -->
        
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">Menu</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="active"><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-link"></i> <span>Halaman Utama</span></a></li>
            <?php $status = Session::get('ssKode') ?>
            <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "customer" || $status[0]->role == "reseller" || $status[0]->role == "owner"): ?>
            <li class="active"><a href="<?php echo e(route('categories.index')); ?>"><i class="fa fa-link"></i> <span>Kategori</span></a></li>
            <?php endif; ?>
            
            <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "customer" || $status[0]->role == "reseller" || $status[0]->role == "owner"): ?>
            <li class="active"><a href="<?php echo e(route('products.index')); ?>"><i class="fa fa-link"></i> <span>Produk</span></a></li>
            <?php endif; ?>

            <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "customer" || $status[0]->role == "owner"): ?>
            <li class="active"><a href="<?php echo e(route('sales.index')); ?>"><i class="fa fa-link"></i> <span>Reseller</span></a></li>
            <?php endif; ?>

            <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "owner"): ?>
            <li class="active"><a href="<?php echo e(route('suppliers.index')); ?>"><i class="fa fa-link"></i> <span>Supplier</span></a></li>
            <?php endif; ?>
            
            <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "owner"): ?>
            <li class="active"><a href="<?php echo e(route('productsOut.index')); ?>"><i class="fa fa-link"></i> <span>Produk Keluar</span></a></li>
            <?php endif; ?>

            <?php if($status[0]->role == "superadmin" || $status[0]->role == "adminpenjualan" || $status[0]->role == "adminproduksi" || $status[0]->role == "owner"): ?>
            <li class="active"><a href="<?php echo e(route('productsIn.index')); ?>"><i class="fa fa-link"></i> <span>Produk Masuk</span></a></li>
            <?php endif; ?>
            <?php if($status[0]->role != "customer"): ?>
            <li class="active"><a href="<?php echo e(route('info.index')); ?>"><i class="fa fa-link"></i> <span>Info</span></a></li>
            <?php endif; ?>
            <li class="active"><a href="<?php echo e(route('tentang.index')); ?>"><i class="fa fa-link"></i> <span>Tentang</span></a></li>
            
            
            
            
            
            
            







        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /home/arrianso/public_html/inventory/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>