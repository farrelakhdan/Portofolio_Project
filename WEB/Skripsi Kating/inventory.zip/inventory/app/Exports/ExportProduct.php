<?php

namespace App\Exports;

use App\Product;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromView;
use Illuminate\Support\Facades\DB;

class ExportProduct implements FromView
{
    /**
     * melakukan format dokumen menggunakan html, maka package ini juga menyediakan fungsi lainnya agar dapat me-load data tersebut dari file html / blade di Laravel
     */
    use Exportable;

    public function view(): View
    {
        // TODO: Implement view() method.
        $product = DB::select('SELECT a.id, b.name, a.nama, a.harga, a.qty, a.image FROM products a
                            LEFT JOIN categories b on a.category_id = b.id');
        return view('products.ProductsAllExcel',[
            'product' => $product
        ]);
    }
}
