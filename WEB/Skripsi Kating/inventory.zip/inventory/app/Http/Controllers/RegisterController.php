<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use App\User;

class RegisterController extends Controller
{
    public function index(Request $request){
        
        $role = "reseller";
        $input = $request->all();
        $input['image'] = null;
        $count = User::where('email', $request->email)->count();
        if ($count == 0) {
            if ($request->hasFile('image')){
                $input['image'] = time().'.'.$request->image->getClientOriginalExtension();
                $request->image->move(public_path('upload/reseller/'), $input['image']);
                DB::select("INSERT INTO users(name,email,password,role) value(?,?,?,'$role')", [$request->name, $request->email, $request->password]);
                DB::select("INSERT INTO sales(nama,alamat,email,image,telepon) value(?,?,?,?,?)", [$request->name, $request->alamat, $request->email, $input['image'], $request->telepon]);
                $success = "Akun Berhasil Dibuat";
                return redirect('login')->with('success',$success);
            }else {
                $error = "Nota tidak ditemukan";
                return redirect('register')->with('error',$error);
            }
        }else{
            $error = "Email Sudah Digunakan";
            return redirect('register')->with('error',$error);
        }
    }
    public function show(){
        return view('auth.register');
    }
}
