<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use App\User;

class LoginController extends Controller
{
    public function index(Request $request){
        $list_data = DB::select('SELECT role FROM users WHERE email=? and password=?', [$request->email,$request->password]);
        if ($list_data) {
            Session::put('ssKode',$list_data);
            $data = DB::select('SELECT name FROM users WHERE email=? and password=?', [$request->email,$request->password]);
            $data1 = DB::select('SELECT email FROM users WHERE email=? and password=?', [$request->email,$request->password]);
            Session::put('nama', $data);
            Session::put('email', $data1);
            $status = "login";
            Session::put('status', $status);
            return redirect()->route('home');
        }else {
            Session::flash('error', 'email atau password salah');
            return redirect()->route('login');
        }
    }

    public function show(){
        $status = "logout";
        Session::forget('status');
        Session::put('status', $status);
        return view('auth.login');
    }

    public function logout(){
        Session::forget('ssKode');
        Session::forget('nama');
        Session::forget('email');
        Session::put('status',"logout");
        return redirect()->route('login');
    }
}