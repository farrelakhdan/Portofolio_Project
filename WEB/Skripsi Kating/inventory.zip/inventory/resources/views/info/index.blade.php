@extends('layouts.master')

@section('top')
@endsection

@section('content')
<!-- Small boxes (Stat box) -->

<div class="row">
    <div class="box">
        <div class="box-body">
        <div class="callout callout-success">
            <h4>CONTACT PERSON</h4>
            <p> <img src="wa.png" class="user-image" alt="User Image"> +62 812-3507-6283</p>
        </div>
        </div>
    </div>
</div>
@endsection

@section('top')
@endsection