@extends('layouts.master')

@section('top')
@endsection

@section('content')
<!-- Small boxes (Stat box) -->

    <div class="row">
        <div class="box">
            <div class="box-body">
            <div class="callout callout-success">
                <h4>N'UP PRODUCT</h4>

                <p> N”Up Product merupakan salah satu UMKM (Usaha Mikro, Kecil, dan Menengah) 
                    yang bergerak dibidang kuliner yang ada di Kabupaten Malang yang berdiri pada tahun 2017, 
                    atas informasi dari ibu Neneng Apriani selaku CEO N”Up Product, N”Up product memiliki 
                    produk Black Garlic and Natural Foods (Bawang Hitam dan Makanan alami). Bawang hitam 
                    adalah produk yang sangat unik dengan cita rasa yang enak dan manfaat yang sangat baik 
                    untuk kesehatan, bawang hitam bisa diolah menjadi berbagai macam makanan (camilan). 
                    N”Up product merupakan UMKM (Usaha Mikro, Kecil, dan Menengah) yang didukung oleh 
                    Dinas Perindustrian dan Perdagangan Kota Malang.</p>
            </div>
            </div>
        </div>
    </div>
@endsection

@section('top')
@endsection