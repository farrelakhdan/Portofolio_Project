<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index(Request $request){
        $role = Session::get('ssKode');
        $status = Session::get('status');
        if ($status == "login") {
            if ($role[0]->role == "superadmin") {
                return view('home');
            }elseif ($role[0]->role == "adminpenjualan") {
                return view('home');
            }elseif ($role[0]->role == "adminproduksi") {
                return view('home');
            }elseif ($role[0]->role == "reseller") {
                return view('home');
            }elseif ($role[0]->role == "customer") {
                return view('home');
            }elseif ($role[0]->role == "owner") {
                return view('home');
            }
        }else {
            Session::forget('nama');
            Session::forget('email');
            Session::forget('status');
            Session::forget('ssKode');
            $status = "logout";
            $role = DB::select('SELECT role FROM users WHERE email="customer@gmail.com" and password="jangandihapus"');
            $data = DB::select('SELECT name FROM users WHERE email="customer@gmail.com" and password="jangandihapus"');
            $data1 = DB::select('SELECT email FROM users WHERE email="customer@gmail.com" and password="jangandihapus"');
            $data[0]->role = "guest";
            Session::put('nama', $data);
            Session::put('email', $data1);
            Session::put('ssKode',$role);
            Session::put('status',$status);
            return view('home');
        }
    }

    public function show(){
        return view('Login');
    }

}